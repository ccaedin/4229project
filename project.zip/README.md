# 4229hw4

For this project I use SDL2 and SDL2 TTL and glm
The required files are arial.ttf, army.cpp, Text.cpp, Text.h

# Operation

You move the view with the left click and the mouse and change the scale with the scroll wheel.
Keybindings:
WASD - move
l/L - dim/brighen power
; - change sky color

# Time Taken
35 hours - complete rewrite in 3.3 and figuring out how to adapt glVertex to Array Objects

# Remainder
I have been stuck on lighting for a while because of how hard it is to debug shader code. I got flickering working, but it is working on too large of an area. I'm thinking of how to make it work on a smaller area, such as adding more subdivisions to the cube. I was working on a flashlight, but I ran out of time. Only 5 lights are working

One of the largest problems I am having is that I can only set my in/out arrays in GLSL to certain sizes depending on the size of the struct. I want to digure out how to bypass this to have as many as I want.

The tutorial I referenced for the normal mapping included a way to turn the winding of vertices into tangents, so I adapted that code to fit different ways of constructing objects, from a simple case with a cube, to much harder with a cylinder and sphere. I stiff how to figure out the spheres so I can re implement the soliders.

I think the current problems will be able to be resolved in office hours, so If I can, I will move on to smoke coming from the torches.

This project has been a lot more challenging than expected. If I am able to find time this week I will as shadow casting.